 <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                         
                        <li>
                            <a href="<?php echo site_url() ?>/admin/dashbord_welcome/index""><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-user"></i> Registered User<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                               
                                <li>
                                    <a href="<?php echo site_url()?>/admin/register_user/index"><i class="fa fa-th-list"></i> List of User</a>
                                </li>
                                <li>
                                    <a href="<?php echo site_url()?>/admin/register_user/nonapproved_list"><i class="fa fa-times-circle"></i>Not Approved</a>
                                </li>
                                <li>
                                    <a href="<?php echo site_url()?>/admin/register_user/approveduser_list"><i class="fa fa-check-circle"></i>Approved</a>
                                </li>
                              
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
<!--                        <li>
                            <a href="<?php echo site_url() ?>/admin/dashbord_welcome/register""><i class="fa fa-table fa-fw"></i> Tables</a>
                        </li>-->
                        
                        
                        
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>