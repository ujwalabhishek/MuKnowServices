 <script>
                                    $(function() {
                                      $( "#min" ).datepicker({
                                       //dateFormat:'y-mm-dd'
                                         });
                                         
                                         
                                         $( "#max" ).datepicker({
                                       //   dateFormat:'y-mm-dd'
                                         });
                                    });
</script>
                                
<script src="<?php echo base_url(JS);?>/jquery.dataTables.columnFilter.js" type="text/javascript"></script>
                                
                                

<link rel="stylesheet" href="<?php echo base_url(CSS);?>/jquery-ui.css">
<script src="<?php echo base_url(JS);?>/jquery-1.10.2.js"></script>
<script src="<?php echo base_url(JS);?>/jquery-ui.js"></script>

<!--<script src="<?php echo base_url(JS);?>/jquery-1.8.0.min.js"></script>
<script src="<?php echo base_url(JS);?>/jquery.validate.js"></script>-->

<link rel="stylesheet" href="/resources/demos/style.css">




<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url();?>/assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url();?>/assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

<!-- DataTables JavaScript -->
<script src="<?php echo base_url();?>/assets/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>/assets/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="../dist/js/sb-admin-2.js"></script>

<!-- Page-Level Demo Scripts - Tables - Use for reference -->
<!--    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>-->
    
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(CSS);?>/buttons.dataTables.min.css">
	<script type="text/javascript" language="javascript" src="<?php echo base_url(JS);?>/dataTables.buttons.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url(JS);?>/jszip.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url(JS);?>/pdfmake.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url(JS);?>/vfs_fonts.js">
	</script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url(JS);?>/buttons.html5.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url(JS);?>/buttons.print.min.js">
	</script>
        
        <!-- filter>-->
      
<!--	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.10/js/jquery.dataTables.min.js">
	</script>
	-->
       
	
	<link rel="stylesheet" type="text/css" href=<?php echo base_url(CSS);?>/jquery.dataTables.min.css">
<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

