<?php require_once('includes/head.php')?>

<body>

    <div id="wrapper">

            <?php require_once('includes/nav.php')?>


        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> <?php echo $ur=$this->uri->segment(3)=='nonapproved_list'? 'Not Approved' : 'Approved'?> Registered user</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <?php echo $ur=$this->uri->segment(3)=='nonapproved_list'? 'Not Approved' : 'Approved'?> Registered User Details
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Mobile No.</th>
                                            <th>Email Id</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                      <?php if(isset($register_user) && count($register_user)):
                                            
                                                    foreach ($register_user as $row) 
                                                {       
                                        ?>
                                        
                                                    <tr class="odd gradeX">
                                                        <td><?php echo ucfirst($row->name)?></td>
                                                        <td><?php echo $row->mobile ?></td>
                                                        <td><?php echo ucfirst($row->email) ?></td>
                                                        <td class="center">
                                                            
                                                            <a href="#"><i data="<?php echo $row ->id?>" class="approve_status   <?php echo ($row-> status)? 'fa fa-check-circle fa-lg' : 'fa fa-times-circle fa-lg'?>"></i> </a>

                                                        </td>

                                                    </tr>
                                     <?php      } 
                                            endif;?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
          
          
            
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    
    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/datatables-responsive/js/dataTables.responsive.js"></script>
    
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>assets/dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                    responsive: true
            });

                $(document).on('click','.approve_status',function(){
                    if(confirm("Are you sure to do this action")){
                      var current_element = $(this);
                      
                      if($(this).hasClass("fa-check-circle")) var status = 0;
                      else var status = 1;
                      url = "<?php echo site_url()?>/admin/register_user/change_status";
                      $.ajax({
                        type:"POST",
                        url: url,
                        data: {user_id:$(current_element).attr('data'),status:status},
                        success: function(data)
                        {   
                          if(status) $(current_element).addClass('fa-check-circle').removeClass('fa-times-circle');
                          else $(current_element).removeClass('fa-check-circle').addClass('fa-times-circle');
                        }
                      });
                    }

                });    
        });
    </script>

</body>

</html>
